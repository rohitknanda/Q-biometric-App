package android.arch.a.a;

import java.util.concurrent.Executor;

public class a extends c {

    /* renamed from: a  reason: collision with root package name */
    private static volatile a f24a;
    private static final Executor d = new Executor() {
        public void execute(Runnable runnable) {
            a.a().b(runnable);
        }
    };
    private static final Executor e = new Executor() {
        public void execute(Runnable runnable) {
            a.a().a(runnable);
        }
    };

    /* renamed from: b  reason: collision with root package name */
    private c f25b = this.c;
    private c c = new b();

    private a() {
    }

    public static a a() {
        if (f24a != null) {
            return f24a;
        }
        synchronized (a.class) {
            if (f24a == null) {
                f24a = new a();
            }
        }
        return f24a;
    }

    public void a(Runnable runnable) {
        this.f25b.a(runnable);
    }

    public void b(Runnable runnable) {
        this.f25b.b(runnable);
    }

    public boolean b() {
        return this.f25b.b();
    }
}
