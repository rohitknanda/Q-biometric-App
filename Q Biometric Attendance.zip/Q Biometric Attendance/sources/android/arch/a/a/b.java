package android.arch.a.a;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class b extends c {

    /* renamed from: a  reason: collision with root package name */
    private final Object f26a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private ExecutorService f27b = Executors.newFixedThreadPool(2);
    private volatile Handler c;

    public void a(Runnable runnable) {
        this.f27b.execute(runnable);
    }

    public void b(Runnable runnable) {
        if (this.c == null) {
            synchronized (this.f26a) {
                if (this.c == null) {
                    this.c = new Handler(Looper.getMainLooper());
                }
            }
        }
        this.c.post(runnable);
    }

    public boolean b() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }
}
