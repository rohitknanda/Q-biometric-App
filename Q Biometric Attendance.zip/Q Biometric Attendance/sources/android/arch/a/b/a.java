package android.arch.a.b;

import android.arch.a.b.b;
import java.util.HashMap;
import java.util.Map;

public class a<K, V> extends b<K, V> {

    /* renamed from: a  reason: collision with root package name */
    private HashMap<K, b.c<K, V>> f28a = new HashMap<>();

    /* access modifiers changed from: protected */
    public b.c<K, V> a(K k) {
        return this.f28a.get(k);
    }

    public V a(K k, V v) {
        b.c a2 = a(k);
        if (a2 != null) {
            return a2.f32b;
        }
        this.f28a.put(k, b(k, v));
        return null;
    }

    public V b(K k) {
        V b2 = super.b(k);
        this.f28a.remove(k);
        return b2;
    }

    public boolean c(K k) {
        return this.f28a.containsKey(k);
    }

    public Map.Entry<K, V> d(K k) {
        if (c(k)) {
            return this.f28a.get(k).d;
        }
        return null;
    }
}
