package android.arch.a.b;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class b<K, V> implements Iterable<Map.Entry<K, V>> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public c<K, V> f29a;

    /* renamed from: b  reason: collision with root package name */
    private c<K, V> f30b;
    private WeakHashMap<f<K, V>, Boolean> c = new WeakHashMap<>();
    private int d = 0;

    static class a<K, V> extends e<K, V> {
        a(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        /* access modifiers changed from: package-private */
        public c<K, V> a(c<K, V> cVar) {
            return cVar.c;
        }

        /* access modifiers changed from: package-private */
        public c<K, V> b(c<K, V> cVar) {
            return cVar.d;
        }
    }

    /* renamed from: android.arch.a.b.b$b  reason: collision with other inner class name */
    private static class C0002b<K, V> extends e<K, V> {
        C0002b(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        /* access modifiers changed from: package-private */
        public c<K, V> a(c<K, V> cVar) {
            return cVar.d;
        }

        /* access modifiers changed from: package-private */
        public c<K, V> b(c<K, V> cVar) {
            return cVar.c;
        }
    }

    static class c<K, V> implements Map.Entry<K, V> {

        /* renamed from: a  reason: collision with root package name */
        final K f31a;

        /* renamed from: b  reason: collision with root package name */
        final V f32b;
        c<K, V> c;
        c<K, V> d;

        c(K k, V v) {
            this.f31a = k;
            this.f32b = v;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return this.f31a.equals(cVar.f31a) && this.f32b.equals(cVar.f32b);
        }

        public K getKey() {
            return this.f31a;
        }

        public V getValue() {
            return this.f32b;
        }

        public V setValue(V v) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public String toString() {
            return this.f31a + "=" + this.f32b;
        }
    }

    private class d implements f<K, V>, Iterator<Map.Entry<K, V>> {

        /* renamed from: b  reason: collision with root package name */
        private c<K, V> f34b;
        private boolean c;

        private d() {
            this.c = true;
        }

        /* renamed from: a */
        public Map.Entry<K, V> next() {
            c<K, V> cVar;
            if (this.c) {
                this.c = false;
                cVar = b.this.f29a;
            } else {
                cVar = this.f34b != null ? this.f34b.c : null;
            }
            this.f34b = cVar;
            return this.f34b;
        }

        public void a_(c<K, V> cVar) {
            if (cVar == this.f34b) {
                this.f34b = this.f34b.d;
                this.c = this.f34b == null;
            }
        }

        public boolean hasNext() {
            return this.c ? b.this.f29a != null : (this.f34b == null || this.f34b.c == null) ? false : true;
        }
    }

    private static abstract class e<K, V> implements f<K, V>, Iterator<Map.Entry<K, V>> {

        /* renamed from: a  reason: collision with root package name */
        c<K, V> f35a;

        /* renamed from: b  reason: collision with root package name */
        c<K, V> f36b;

        e(c<K, V> cVar, c<K, V> cVar2) {
            this.f35a = cVar2;
            this.f36b = cVar;
        }

        private c<K, V> b() {
            if (this.f36b == this.f35a || this.f35a == null) {
                return null;
            }
            return a(this.f36b);
        }

        /* access modifiers changed from: package-private */
        public abstract c<K, V> a(c<K, V> cVar);

        /* renamed from: a */
        public Map.Entry<K, V> next() {
            c<K, V> cVar = this.f36b;
            this.f36b = b();
            return cVar;
        }

        public void a_(c<K, V> cVar) {
            if (this.f35a == cVar && cVar == this.f36b) {
                this.f36b = null;
                this.f35a = null;
            }
            if (this.f35a == cVar) {
                this.f35a = b(this.f35a);
            }
            if (this.f36b == cVar) {
                this.f36b = b();
            }
        }

        /* access modifiers changed from: package-private */
        public abstract c<K, V> b(c<K, V> cVar);

        public boolean hasNext() {
            return this.f36b != null;
        }
    }

    interface f<K, V> {
        void a_(c<K, V> cVar);
    }

    public int a() {
        return this.d;
    }

    /* access modifiers changed from: protected */
    public c<K, V> a(K k) {
        c<K, V> cVar = this.f29a;
        while (cVar != null && !cVar.f31a.equals(k)) {
            cVar = cVar.c;
        }
        return cVar;
    }

    public V a(K k, V v) {
        c a2 = a(k);
        if (a2 != null) {
            return a2.f32b;
        }
        b(k, v);
        return null;
    }

    /* access modifiers changed from: protected */
    public c<K, V> b(K k, V v) {
        c<K, V> cVar = new c<>(k, v);
        this.d++;
        if (this.f30b == null) {
            this.f29a = cVar;
            this.f30b = this.f29a;
            return cVar;
        }
        this.f30b.c = cVar;
        cVar.d = this.f30b;
        this.f30b = cVar;
        return cVar;
    }

    public V b(K k) {
        c a2 = a(k);
        if (a2 == null) {
            return null;
        }
        this.d--;
        if (!this.c.isEmpty()) {
            for (f<K, V> a_ : this.c.keySet()) {
                a_.a_(a2);
            }
        }
        if (a2.d != null) {
            a2.d.c = a2.c;
        } else {
            this.f29a = a2.c;
        }
        if (a2.c != null) {
            a2.c.d = a2.d;
        } else {
            this.f30b = a2.d;
        }
        a2.c = null;
        a2.d = null;
        return a2.f32b;
    }

    public Iterator<Map.Entry<K, V>> b() {
        C0002b bVar = new C0002b(this.f30b, this.f29a);
        this.c.put(bVar, false);
        return bVar;
    }

    public b<K, V>.d c() {
        b<K, V>.d dVar = new d();
        this.c.put(dVar, false);
        return dVar;
    }

    public Map.Entry<K, V> d() {
        return this.f29a;
    }

    public Map.Entry<K, V> e() {
        return this.f30b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        if (a() != bVar.a()) {
            return false;
        }
        Iterator it = iterator();
        Iterator it2 = bVar.iterator();
        while (it.hasNext() && it2.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            Object next = it2.next();
            if ((entry == null && next != null) || (entry != null && !entry.equals(next))) {
                return false;
            }
        }
        return !it.hasNext() && !it2.hasNext();
    }

    public Iterator<Map.Entry<K, V>> iterator() {
        a aVar = new a(this.f29a, this.f30b);
        this.c.put(aVar, false);
        return aVar;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator it = iterator();
        while (it.hasNext()) {
            sb.append(((Map.Entry) it.next()).toString());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
