package android.arch.lifecycle;

public class AndroidViewModel extends n {
}
