package android.arch.lifecycle;

interface FullLifecycleObserver extends d {
    void a(e eVar);

    void b(e eVar);

    void c(e eVar);

    void d(e eVar);

    void e(e eVar);

    void f(e eVar);
}
