package android.arch.lifecycle;

import android.arch.a.b.b;
import android.arch.lifecycle.c;
import java.util.Map;

public abstract class LiveData<T> {
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public static final Object f40b = new Object();
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final Object f41a = new Object();
    private b<k<T>, LiveData<T>.a> c = new b<>();
    /* access modifiers changed from: private */
    public int d = 0;
    private volatile Object e = f40b;
    /* access modifiers changed from: private */
    public volatile Object f = f40b;
    private int g = -1;
    private boolean h;
    private boolean i;
    private final Runnable j = new Runnable() {
        public void run() {
            Object b2;
            synchronized (LiveData.this.f41a) {
                b2 = LiveData.this.f;
                Object unused = LiveData.this.f = LiveData.f40b;
            }
            LiveData.this.b(b2);
        }
    };

    class LifecycleBoundObserver extends LiveData<T>.a implements GenericLifecycleObserver {

        /* renamed from: a  reason: collision with root package name */
        final e f43a;

        LifecycleBoundObserver(e eVar, k<T> kVar) {
            super(kVar);
            this.f43a = eVar;
        }

        public void a(e eVar, c.a aVar) {
            if (this.f43a.a().a() == c.b.DESTROYED) {
                LiveData.this.a(this.c);
            } else {
                a(a());
            }
        }

        /* access modifiers changed from: package-private */
        public boolean a() {
            return this.f43a.a().a().a(c.b.STARTED);
        }

        /* access modifiers changed from: package-private */
        public boolean a(e eVar) {
            return this.f43a == eVar;
        }

        /* access modifiers changed from: package-private */
        public void b() {
            this.f43a.a().b(this);
        }
    }

    private abstract class a {
        final k<T> c;
        boolean d;
        int e = -1;

        a(k<T> kVar) {
            this.c = kVar;
        }

        /* access modifiers changed from: package-private */
        public void a(boolean z) {
            if (z != this.d) {
                this.d = z;
                int i = 1;
                boolean z2 = LiveData.this.d == 0;
                LiveData liveData = LiveData.this;
                int c2 = liveData.d;
                if (!this.d) {
                    i = -1;
                }
                int unused = liveData.d = c2 + i;
                if (z2 && this.d) {
                    LiveData.this.b();
                }
                if (LiveData.this.d == 0 && !this.d) {
                    LiveData.this.c();
                }
                if (this.d) {
                    LiveData.this.b((LiveData<T>.a) this);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public abstract boolean a();

        /* access modifiers changed from: package-private */
        public boolean a(e eVar) {
            return false;
        }

        /* access modifiers changed from: package-private */
        public void b() {
        }
    }

    private void a(LiveData<T>.a aVar) {
        if (aVar.d) {
            if (!aVar.a()) {
                aVar.a(false);
            } else if (aVar.e < this.g) {
                aVar.e = this.g;
                aVar.c.a(this.e);
            }
        }
    }

    private static void a(String str) {
        if (!android.arch.a.a.a.a().b()) {
            throw new IllegalStateException("Cannot invoke " + str + " on a background" + " thread");
        }
    }

    /* access modifiers changed from: private */
    public void b(LiveData<T>.a aVar) {
        if (this.h) {
            this.i = true;
            return;
        }
        this.h = true;
        do {
            this.i = false;
            if (aVar == null) {
                b<K, V>.d c2 = this.c.c();
                while (c2.hasNext()) {
                    a((LiveData<T>.a) (a) ((Map.Entry) c2.next()).getValue());
                    if (this.i) {
                        break;
                    }
                }
            } else {
                a(aVar);
                aVar = null;
            }
        } while (this.i);
        this.h = false;
    }

    public T a() {
        T t = this.e;
        if (t != f40b) {
            return t;
        }
        return null;
    }

    public void a(e eVar, k<T> kVar) {
        if (eVar.a().a() != c.b.DESTROYED) {
            LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(eVar, kVar);
            a a2 = this.c.a(kVar, lifecycleBoundObserver);
            if (a2 != null && !a2.a(eVar)) {
                throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
            } else if (a2 == null) {
                eVar.a().a(lifecycleBoundObserver);
            }
        }
    }

    public void a(k<T> kVar) {
        a("removeObserver");
        a b2 = this.c.b(kVar);
        if (b2 != null) {
            b2.b();
            b2.a(false);
        }
    }

    /* access modifiers changed from: protected */
    public void a(T t) {
        boolean z;
        synchronized (this.f41a) {
            z = this.f == f40b;
            this.f = t;
        }
        if (z) {
            android.arch.a.a.a.a().b(this.j);
        }
    }

    /* access modifiers changed from: protected */
    public void b() {
    }

    /* access modifiers changed from: protected */
    public void b(T t) {
        a("setValue");
        this.g++;
        this.e = t;
        b((LiveData<T>.a) null);
    }

    /* access modifiers changed from: protected */
    public void c() {
    }

    public boolean d() {
        return this.d > 0;
    }
}
