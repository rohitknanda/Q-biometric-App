package android.arch.lifecycle;

import android.arch.lifecycle.a;
import android.arch.lifecycle.c;

class ReflectiveGenericLifecycleObserver implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    private final Object f45a;

    /* renamed from: b  reason: collision with root package name */
    private final a.C0003a f46b = a.f48a.b(this.f45a.getClass());

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.f45a = obj;
    }

    public void a(e eVar, c.a aVar) {
        this.f46b.a(eVar, aVar, this.f45a);
    }
}
