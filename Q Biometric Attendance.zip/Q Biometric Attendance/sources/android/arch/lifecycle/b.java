package android.arch.lifecycle;

import android.arch.lifecycle.c;

public interface b {
    void a(e eVar, c.a aVar, boolean z, i iVar);
}
