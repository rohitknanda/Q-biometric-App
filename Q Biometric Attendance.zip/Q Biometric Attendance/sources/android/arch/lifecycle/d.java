package android.arch.lifecycle;

public interface d {
}
