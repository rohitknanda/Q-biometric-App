package android.arch.lifecycle;

import android.arch.a.b.b;
import android.arch.lifecycle.c;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class f extends c {

    /* renamed from: a  reason: collision with root package name */
    private android.arch.a.b.a<d, a> f56a = new android.arch.a.b.a<>();

    /* renamed from: b  reason: collision with root package name */
    private c.b f57b;
    private final WeakReference<e> c;
    private int d = 0;
    private boolean e = false;
    private boolean f = false;
    private ArrayList<c.b> g = new ArrayList<>();

    static class a {

        /* renamed from: a  reason: collision with root package name */
        c.b f60a;

        /* renamed from: b  reason: collision with root package name */
        GenericLifecycleObserver f61b;

        a(d dVar, c.b bVar) {
            this.f61b = h.a((Object) dVar);
            this.f60a = bVar;
        }

        /* access modifiers changed from: package-private */
        public void a(e eVar, c.a aVar) {
            c.b b2 = f.b(aVar);
            this.f60a = f.a(this.f60a, b2);
            this.f61b.a(eVar, aVar);
            this.f60a = b2;
        }
    }

    public f(e eVar) {
        this.c = new WeakReference<>(eVar);
        this.f57b = c.b.INITIALIZED;
    }

    static c.b a(c.b bVar, c.b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    private void a(e eVar) {
        b<K, V>.d c2 = this.f56a.c();
        while (c2.hasNext() && !this.f) {
            Map.Entry entry = (Map.Entry) c2.next();
            a aVar = (a) entry.getValue();
            while (aVar.f60a.compareTo(this.f57b) < 0 && !this.f && this.f56a.c(entry.getKey())) {
                c(aVar.f60a);
                aVar.a(eVar, e(aVar.f60a));
                c();
            }
        }
    }

    static c.b b(c.a aVar) {
        switch (aVar) {
            case ON_CREATE:
            case ON_STOP:
                return c.b.CREATED;
            case ON_START:
            case ON_PAUSE:
                return c.b.STARTED;
            case ON_RESUME:
                return c.b.RESUMED;
            case ON_DESTROY:
                return c.b.DESTROYED;
            default:
                throw new IllegalArgumentException("Unexpected event value " + aVar);
        }
    }

    private void b(c.b bVar) {
        if (this.f57b != bVar) {
            this.f57b = bVar;
            if (this.e || this.d != 0) {
                this.f = true;
                return;
            }
            this.e = true;
            d();
            this.e = false;
        }
    }

    private void b(e eVar) {
        Iterator<Map.Entry<d, a>> b2 = this.f56a.b();
        while (b2.hasNext() && !this.f) {
            Map.Entry next = b2.next();
            a aVar = (a) next.getValue();
            while (aVar.f60a.compareTo(this.f57b) > 0 && !this.f && this.f56a.c(next.getKey())) {
                c.a d2 = d(aVar.f60a);
                c(b(d2));
                aVar.a(eVar, d2);
                c();
            }
        }
    }

    private boolean b() {
        if (this.f56a.a() == 0) {
            return true;
        }
        c.b bVar = this.f56a.d().getValue().f60a;
        c.b bVar2 = this.f56a.e().getValue().f60a;
        return bVar == bVar2 && this.f57b == bVar2;
    }

    private c.b c(d dVar) {
        Map.Entry<d, a> d2 = this.f56a.d(dVar);
        c.b bVar = null;
        c.b bVar2 = d2 != null ? d2.getValue().f60a : null;
        if (!this.g.isEmpty()) {
            bVar = this.g.get(this.g.size() - 1);
        }
        return a(a(this.f57b, bVar2), bVar);
    }

    private void c() {
        this.g.remove(this.g.size() - 1);
    }

    private void c(c.b bVar) {
        this.g.add(bVar);
    }

    private static c.a d(c.b bVar) {
        switch (bVar) {
            case INITIALIZED:
                throw new IllegalArgumentException();
            case CREATED:
                return c.a.ON_DESTROY;
            case STARTED:
                return c.a.ON_STOP;
            case RESUMED:
                return c.a.ON_PAUSE;
            case DESTROYED:
                throw new IllegalArgumentException();
            default:
                throw new IllegalArgumentException("Unexpected state value " + bVar);
        }
    }

    private void d() {
        e eVar = (e) this.c.get();
        if (eVar == null) {
            Log.w("LifecycleRegistry", "LifecycleOwner is garbage collected, you shouldn't try dispatch new events from it.");
            return;
        }
        while (!b()) {
            this.f = false;
            if (this.f57b.compareTo(this.f56a.d().getValue().f60a) < 0) {
                b(eVar);
            }
            Map.Entry<d, a> e2 = this.f56a.e();
            if (!this.f && e2 != null && this.f57b.compareTo(e2.getValue().f60a) > 0) {
                a(eVar);
            }
        }
        this.f = false;
    }

    private static c.a e(c.b bVar) {
        switch (bVar) {
            case INITIALIZED:
            case DESTROYED:
                return c.a.ON_CREATE;
            case CREATED:
                return c.a.ON_START;
            case STARTED:
                return c.a.ON_RESUME;
            case RESUMED:
                throw new IllegalArgumentException();
            default:
                throw new IllegalArgumentException("Unexpected state value " + bVar);
        }
    }

    public c.b a() {
        return this.f57b;
    }

    public void a(c.a aVar) {
        b(b(aVar));
    }

    public void a(c.b bVar) {
        b(bVar);
    }

    public void a(d dVar) {
        e eVar;
        a aVar = new a(dVar, this.f57b == c.b.DESTROYED ? c.b.DESTROYED : c.b.INITIALIZED);
        if (this.f56a.a(dVar, aVar) == null && (eVar = (e) this.c.get()) != null) {
            boolean z = this.d != 0 || this.e;
            c.b c2 = c(dVar);
            this.d++;
            while (aVar.f60a.compareTo(c2) < 0 && this.f56a.c(dVar)) {
                c(aVar.f60a);
                aVar.a(eVar, e(aVar.f60a));
                c();
                c2 = c(dVar);
            }
            if (!z) {
                d();
            }
            this.d--;
        }
    }

    public void b(d dVar) {
        this.f56a.b(dVar);
    }
}
