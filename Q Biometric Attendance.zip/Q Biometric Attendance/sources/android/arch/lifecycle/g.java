package android.arch.lifecycle;

@Deprecated
public interface g extends e {
    f b();
}
