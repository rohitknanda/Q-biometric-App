package android.arch.lifecycle;

import java.util.HashMap;
import java.util.Map;

public class i {

    /* renamed from: a  reason: collision with root package name */
    private Map<String, Integer> f64a = new HashMap();
}
