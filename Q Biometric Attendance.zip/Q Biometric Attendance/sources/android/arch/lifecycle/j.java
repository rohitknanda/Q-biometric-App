package android.arch.lifecycle;

public class j<T> extends LiveData<T> {
    public void a(T t) {
        super.a(t);
    }

    public void b(T t) {
        super.b(t);
    }
}
