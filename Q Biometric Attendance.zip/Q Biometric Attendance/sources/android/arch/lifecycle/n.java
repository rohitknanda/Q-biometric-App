package android.arch.lifecycle;

public abstract class n {
    /* access modifiers changed from: protected */
    public void a() {
    }
}
