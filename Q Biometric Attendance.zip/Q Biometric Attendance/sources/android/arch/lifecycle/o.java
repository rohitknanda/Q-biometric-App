package android.arch.lifecycle;

public class o {

    /* renamed from: a  reason: collision with root package name */
    private final a f66a;

    /* renamed from: b  reason: collision with root package name */
    private final p f67b;

    public interface a {
        <T extends n> T a(Class<T> cls);
    }

    public o(p pVar, a aVar) {
        this.f66a = aVar;
        this.f67b = pVar;
    }

    public <T extends n> T a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        return a("android.arch.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName, cls);
    }

    public <T extends n> T a(String str, Class<T> cls) {
        T a2 = this.f67b.a(str);
        if (cls.isInstance(a2)) {
            return a2;
        }
        T a3 = this.f66a.a(cls);
        this.f67b.a(str, a3);
        return a3;
    }
}
