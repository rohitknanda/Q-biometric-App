package android.arch.lifecycle;

import java.util.HashMap;

public class p {

    /* renamed from: a  reason: collision with root package name */
    private final HashMap<String, n> f68a = new HashMap<>();

    /* access modifiers changed from: package-private */
    public final n a(String str) {
        return this.f68a.get(str);
    }

    public final void a() {
        for (n a2 : this.f68a.values()) {
            a2.a();
        }
        this.f68a.clear();
    }

    /* access modifiers changed from: package-private */
    public final void a(String str, n nVar) {
        n nVar2 = this.f68a.get(str);
        if (nVar2 != null) {
            nVar2.a();
        }
        this.f68a.put(str, nVar);
    }
}
